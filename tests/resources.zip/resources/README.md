# README

CSVs of Octave-generated arrays for testing Python implementation.
